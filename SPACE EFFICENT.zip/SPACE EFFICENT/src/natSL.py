import time

from src.natATLwithRecall import existentialNatATL, universalNatATL
from util.natSLparser import convert_natsl_to_natatl_separated
import os
def natSL(model, formula_file, results_file):

    start_time = time.time()
    #Step 0: setting formule natATL da NatSL
    formula_file = os.path.abspath(formula_file)
    if not os.path.isfile(formula_file):
        raise FileNotFoundError(f"No such file or directory: {formula_file}")
    with open(formula_file, 'r') as f:
        natSLformula = f.read().strip()
    print(f"formula NatSL: {natSLformula}")
    #TRASFORMA QUI NATSTL FORMULA IN NATSL ESISTENZIALE E UNIVERSALE (funzione di conversione presente in natSL parser)
    existential_natatl, universal_natatl = convert_natsl_to_natatl_separated(natSLformula)
    print(f"existential NatATL formula: {existential_natatl}")
    print(f"universal NatATL formula: {universal_natatl}")
    #Memorizzo le formule separate in una lista per manutenibilità e future espansioni se necessario, ma passo il primo elemento come stringa sotto
    #Questo perchè il codice si aspetta una formula come stringa non come lista

    # Step 1: Chiamata alla funzione existentialNatATL
    solution, trees, height = existentialNatATL(model, existential_natatl[0], results_file)

    # Step 2: Se una soluzione esistenziale è stata trovata, termina con successo
    if solution:
        # End timer
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Elapsed time is {elapsed_time} seconds.")
        with open(results_file, 'w') as f:
            f.write(f"time is {elapsed_time}")
        return solution

    # Step 3: Se non c'è soluzione esistenziale, passa alle strategie universali
    print("Switching to universal strategies.")
    flag = universalNatATL(trees, model, universal_natatl[0], results_file, ["s0","s1","s2","s3"], 2, height, start_time)

