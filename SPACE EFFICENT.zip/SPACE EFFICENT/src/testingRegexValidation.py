import multiprocessing
from src.strategies import initialize, generate_guarded_action_pairs, create_reg_exp, generate_strategies
import time
from src.tree import depth_first_search, build_tree_from_CGS
from util.read_input import get_states

def natATLwithRecall(model, formula, results_file):
    start_time = time.time()
    found_solution = False
    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, filename, cgs = initialize(model, formula)
    reg_exp = create_reg_exp(k, atomic_propositions)
    conditions = list(reg_exp)
    actions = list(actions_list)
    tree = build_tree_from_CGS(cgs, get_states(), 3)  # sostituisci altezza con #n di stati
    print("Initial Tree built from input model:")
    print(tree)
    path = depth_first_search(tree, "h.h.h", 3, 3)
    if path is None:
        print("No path matches the regex condition")
        return False

    print("Path matching the regex condition:", path)

    # End timer
    end_time = time.time()
    print(f"Total time: {end_time - start_time}")

def algorithm():
    path = 'C:\\Users\\utente\\Desktop\\Lavoro\\Progetti con Vadim\\RecallNATATL\\Testing\\Next with n agents\\testing2\\model.txt'
    result = 'C:\\Users\\utente\\Desktop\\Lavoro\\Progetti con Vadim\\RecallNATATL\\Testing\\Next with n agents\\testing2\\result.txt'
    formula = 'C:\\Users\\utente\\Desktop\\Lavoro\\Progetti con Vadim\\RecallNATATL\\Testing\\Next with n agents\\testing2\\formula.txt'

    # main function
    natATLwithRecall(path, formula, result)

if __name__ == "__main__":
    process = multiprocessing.Process(target=algorithm)
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()