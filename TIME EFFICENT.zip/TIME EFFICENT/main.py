from src.natSL import natSL
import multiprocessing

def algorithm():
    path = "C:\\Users\\utente\\Desktop\\Lavoro\\NatSL\\Testing\\Correttezza\\Exists Eventually with n agents\\Next K=4\\testing8\\testing.txt"
    result = "C:\\Users\\utente\\Desktop\\Lavoro\\NatSL\\Testing\\Correttezza\\Exists Eventually with n agents\\Next K=4\\testing8\\Risultato.txt"
    formula = 'C:\\Users\\utente\\Desktop\\Lavoro\\NatSL\\natSLformula.txt'

    # main function
    natSL(path, formula, result)

if __name__ == "__main__":
    process = multiprocessing.Process(target=algorithm)
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()

#PROSSIMI TEST: CON 3 AGENTI GENERAZIONE DI STRATEGIE NON FUNZIONA


