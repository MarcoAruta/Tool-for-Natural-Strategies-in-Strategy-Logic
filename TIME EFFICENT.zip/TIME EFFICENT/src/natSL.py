from src.natATLwithRecall import existentialNatATL
import os
import time
from util.natSLparser import convert_natsl_to_natatl_separated


def natSL(model, formula_file, results_file):
    start_time = time.time()

   #Step 0: setting formule natATL da NatSL
    formula_file = os.path.abspath(formula_file)
    if not os.path.isfile(formula_file):
        raise FileNotFoundError(f"No such file or directory: {formula_file}")
    with open(formula_file, 'r') as f:
        formula = f.read().strip()
    print(f"formula NatSL: {formula}")
    # Converte formula NatSL in NatATL
    existential_natatl, universal_natatl = convert_natsl_to_natatl_separated(formula)
    print(f"existential NatATL formula: {existential_natatl}")
    print(f"universal NatATL formula: {universal_natatl}")
    # Chiama la funzione per strategie esistenziali
    solution = existentialNatATL(model, existential_natatl[0], universal_natatl[0], results_file, start_time)

    # Se non c'è soluzione esistenziale, FINE
    if not solution:
        print("No solution.")
        end_time = time.time()
        print(f"Elapsed time for universalNatATL is {end_time - start_time} seconds.")
        #flag = universalNatATL(trees, model, universalNatATLformula_path, results_file, ["s0", "s1", "s2", "s3"], 0, height)

        #if flag:
        #    print("Universal validation succeeded. Solution found.")
        #else:
         #   print("No solution found. The formula is not satisfied.")



