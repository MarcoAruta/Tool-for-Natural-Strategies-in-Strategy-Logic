import multiprocessing
from src.strategies import initialize, generate_guarded_action_pairs, create_reg_exp, generate_strategies
import time


def natATLwithRecall(model, formula, results_file):
    start_time = time.time()
    found_solution = False
    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, filename, cgs = initialize(model, formula)
    i = 1 #to custom upper complexity bound value for generated strategies
    while not found_solution and i <= k:
        reg_exp = create_reg_exp(k, atomic_propositions)
        conditions = list(reg_exp)
        actions = list(actions_list)
        cartesian_products = generate_guarded_action_pairs(conditions, actions)
        print(f"cartesian prods {cartesian_products}")
        strategies_iterator = generate_strategies(cartesian_products, k, agents, found_solution)

        for collective_strategy in strategies_iterator:
            print(f"check this strategy set for agents {collective_strategy}")
            # Aggiungi qui la logica per verificare la strategia collettiva e impostare found_solution su True se trovi una soluzione valida

        i += 1

    # End timer
    end_time = time.time()
    print(f"Total time: {end_time - start_time}")

def algorithm():
    path = 'C:\\Users\\utente\\Desktop\\Lavoro\\Progetti con Vadim\\RecallNATATL\\Testing\\Next with n agents\\testing2\\model.txt'
    result = 'C:\\Users\\utente\\Desktop\\Lavoro\\Progetti con Vadim\\RecallNATATL\\Testing\\Next with n agents\\testing2\\result.txt'
    formula = 'C:\\Users\\utente\\Desktop\\Lavoro\\Progetti con Vadim\\RecallNATATL\\Testing\\Next with n agents\\testing2\\formula.txt'

    # main function
    natATLwithRecall(path, formula, result)

if __name__ == "__main__":
    process = multiprocessing.Process(target=algorithm)
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()