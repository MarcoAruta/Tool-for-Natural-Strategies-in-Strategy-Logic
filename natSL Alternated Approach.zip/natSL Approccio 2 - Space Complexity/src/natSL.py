from src.strategies import initialize, generate_guarded_action_pairs, create_reg_exp, generate_strategies
from src.pruning import pruning
from util.read_input import get_states, get_number_of_states
from src.tree import build_tree_from_CGS
import time
import copy

#Algoritmo approccio 2 (space expansive...tree list)
def natSLmc(model, formula, results_file):
    start_time = time.time()
    tree_list=[]
    found_solution = False
    flag=1
    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, filename, cgs = initialize(model, formula, flag)
    i = 1
    height = 4 #max height is 5 if you want RT results
    while not found_solution and i <= k:
        print(f"cgs {cgs}")
        tree = build_tree_from_CGS(cgs, get_states(), height) #sostituisci altezza con #n di stati
        print("Initial Tree built from input model:")
        print(tree)
        reg_exp = create_reg_exp(k, atomic_propositions)
        conditions = list(reg_exp)
        actions = list(actions_list)
        cartesian_products = generate_guarded_action_pairs(conditions, actions)
        print(f"cartesian prods {cartesian_products}")
        #la generazione di agenti esistenziali/universali che siano è filtrata nel file strategies.py per initialize()
        strategies_iterator = generate_strategies(cartesian_products, k, agents, found_solution)

        for collective_strategy in strategies_iterator:
            print(f"check this strategy set for agents {collective_strategy}")
            tree_copy = copy.deepcopy(tree)  # Crea una copia profonda dell'albero per non modificare ad ogni nuova proiezione di strategia l'albero originale
            if pruning(tree_copy, height, filename, CTLformula, *collective_strategy):
                print(f"Solution found {collective_strategy}")
                with open(results_file, 'w') as f:
                    f.write(f"Solution found: {collective_strategy}")
                found_solution = True
                break
            tree_list.append(tree_copy) #aggiungo ad una lista apposita ogni albero prunato

        i += 1
    else:
        if not found_solution: #tutte le strategie generate
            print(f"No Solution found for existential strategies")
            flag = 0
            k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, filename, cgs = initialize(model, formula, flag)
            i = 1
            while i <= k:
                for tree in tree_list:  # Loop over all trees in the pre-defined tree list
                    print(f"Checking tree {tree}")
                    under_exam = False  # Flag for each tree

                    reg_exp = create_reg_exp(k, atomic_propositions)
                    conditions = list(reg_exp)
                    actions = list(actions_list)
                    cartesian_products = generate_guarded_action_pairs(conditions, actions)
                    print(f"Cartesian products {cartesian_products}")
                    strategies_iterator = generate_strategies(cartesian_products, k, agents, found_solution)

                    all_strategies_success = True  # Flag to check if all strategies succeed for the current tree

                    for collective_strategy in strategies_iterator:
                        print(f"Checking this strategy set for agents: {collective_strategy}")
                        tree_copy = copy.deepcopy(tree)  # Copy the tree to avoid modifying the original

                        if pruning(tree_copy, height, filename, CTLformula, *collective_strategy):
                            print(f"Pruning succeeded for strategy: {collective_strategy}")
                            under_exam = True  # Mark the tree as under examination
                        else:
                            print(f"Pruning failed for strategy: {collective_strategy}")
                            all_strategies_success = False  # If any strategy fails, move to the next tree
                            break  # Exit the strategy loop early since this tree failed for at least one strategy

                    if all_strategies_success and under_exam:
                        # If all strategies succeed and the tree is under examination
                        print(f"Solution found for tree: {tree} with strategy: {collective_strategy}")
                        with open(results_file, 'w') as f:
                            f.write(f"Solution found with tree: {tree} and strategy: {collective_strategy}")
                        found_solution = True
                        break  # Exit the tree loop since a solution is found for this tree

                if found_solution:
                    break  # Exit the outer loop if a solution is found across all strategies for a tree

                i += 1

            if not found_solution:
                print("No Solution found")
                with open(results_file, 'w') as f:
                    f.write("No solution found")

    # End timer
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Elapsed time is {elapsed_time} seconds.")
    with open(results_file, 'w') as f:
        f.write(f"time is {elapsed_time}")

