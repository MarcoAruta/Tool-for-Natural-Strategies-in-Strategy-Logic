import ply.lex as lex
import ply.yacc as yacc

# Tokens for NatSL
tokens = (
    'COLON', # ':'
    'LPAREN', # '('
    'RPAREN', # ')'
    'COMMA', # ','
    'EXIST', # 'E'
    'FORALL', # 'A'
    'BINDING', # Variables for bindings like 'x', 'y', 'z'
    'AGENT', # Agents now as numbers (e.g., '1', '2', '3')
    'EVENTUALLY', # 'F'
    'PROP', # Propositions like 'p', 'q'
    'NEG' # Negation '!'
)

# Regular expressions for tokens
t_COLON = r':'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_COMMA = r','
t_EXIST = r'E'
t_FORALL = r'A'
t_BINDING = r'[xyz]'
t_AGENT = r'\d+'
t_EVENTUALLY = r'F'
t_PROP = r'[abcdefgh]'
t_NEG = r'!'

# Token error handling
def t_error(t):
    t.lexer.skip(1)

# Grammar rules for NatSL
def p_formula(p):
    '''formula : quantifiers COLON binding_pairs temporal_expression'''
    p[0] = (p[1], p[3], p[4])

def p_quantifiers(p):
    '''quantifiers : quantifier
                   | quantifiers quantifier'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

def p_quantifier(p):
    '''quantifier : EXIST BINDING
                  | FORALL BINDING'''
    p[0] = (p[1], p[2])

def p_binding_pairs(p):
    '''binding_pairs : binding_pair
                     | binding_pairs binding_pair'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

def p_binding_pair(p):
    '''binding_pair : LPAREN BINDING COMMA AGENT RPAREN'''
    p[0] = (p[2], p[4])

def p_temporal_expression(p):
    '''temporal_expression : negation_expression
                           | EVENTUALLY PROP'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = ('F', p[2])

def p_negation_expression(p):
    '''negation_expression : NEG EVENTUALLY PROP'''
    p[0] = ('!', 'F', p[3])

# Error rule for syntax errors
def p_error(p):
    if p:
        print(f"Syntax error at '{p.value}'")
    else:
        print("Syntax error at EOF")

# Build the lexer and parser
def get_lexer():
    lexer = lex.lex()
    return lexer

def get_parser():
    parser = yacc.yacc()
    return parser

def do_parsingNatSL(formula):
    lexer = get_lexer()
    parser = get_parser()
    try:
        result = parser.parse(formula, lexer=lexer)
        return result
    except SyntaxError:
        return None

def validate_bindings(parsed_formula):
    """
    Validates that all binding variables in the quantifiers are associated with an agent.
    """
    quantifiers, binding_pairs, _ = parsed_formula
    bound_variables = {var for var, _ in binding_pairs}
    for _, binding_var in quantifiers:
        if binding_var not in bound_variables:
            raise ValueError(f"Error: Binding variable '{binding_var}' is not associated with any agent.")

def count_agents(parsed_formula):
    """
    Counts the number of unique agents used in the formula.
    """
    _, binding_pairs, _ = parsed_formula
    agents = {int(agent) for _, agent in binding_pairs}
    return len(agents)

def extract_existential_agents(parsed_formula):
    """
    Extracts existential agents from the NatSL formula.
    """
    quantifiers, binding_pairs, _ = parsed_formula
    existential_variables = [var for q, var in quantifiers if q == 'E']
    map_vars_to_agents = {var: agent for var, agent in binding_pairs}
    existential_agents = [int(map_vars_to_agents[var]) for var in existential_variables if var in map_vars_to_agents]
    return existential_agents

def extract_universal_agents(parsed_formula):
    """
    Extracts universal agents from the NatSL formula.
    """
    quantifiers, binding_pairs, _ = parsed_formula
    universal_variables = [var for q, var in quantifiers if q == 'A']
    map_vars_to_agents = {var: agent for var, agent in binding_pairs}
    universal_agents = [int(map_vars_to_agents[var]) for var in universal_variables if var in map_vars_to_agents]
    return universal_agents

def extract_formula(parsed_formula):
    """
    Extracts the temporal operator and associated proposition from the NatSL formula.
    """
    _, _, temporal_expr = parsed_formula
    operator, proposition = temporal_expr
    return operator + proposition

def convert_natsl_to_ctl(parsed_formula, flag):
    """
    Converts a parsed NatSL formula into its corresponding CTL formula using the universal path quantifier 'A'.
    """
    quantifiers, binding_pairs, temporal_expr = parsed_formula

    if flag == 1:
        temporal_operator, proposition = temporal_expr
        ctl_formula = f"!A{temporal_operator}{proposition}"
    else:
        temporal_operator, proposition = temporal_expr
        ctl_formula = f"A{temporal_operator}{proposition}"

    return ctl_formula

def normalize_formula(formula):
    fully_negated = False

    if formula.startswith("!(") and formula.endswith(")"):
        fully_negated = True
        formula = formula[2:-1]

    quantifiers_part, rest = formula.split(":", 1)

    normalized_quantifiers = []
    for q in quantifiers_part:
        if q == 'E':
            normalized_quantifiers.append('A' if fully_negated else 'E')
        elif q == 'A':
            normalized_quantifiers.append('E' if fully_negated else 'A')
        else:
            normalized_quantifiers.append(q)

    normalized_formula = "".join(normalized_quantifiers) + ":" + rest
    return fully_negated, normalized_formula

def skolemize_formula(parsed_formula):
    """
    Applies Skolemization to the formula, rewriting it with existential quantifiers first, followed by universal quantifiers.
    """
    quantifiers, binding_pairs, temporal_expr = parsed_formula

    # Separate existential and universal quantifiers
    existentials = [(q, var) for q, var in quantifiers if q == 'E']
    universals = [(q, var) for q, var in quantifiers if q == 'A']

    # Combine them with existentials first
    skolemized_quantifiers = existentials + universals

    skolemized_formula = (skolemized_quantifiers, binding_pairs, temporal_expr)
    return skolemized_formula

# Example usage
if __name__ == "__main__":
    formula = "ExAyEz:(x,1)(y,2)(z,3)Fh"
    print("Formula:", formula)

    flag, normalized_formula = normalize_formula(formula)
    print("Formula Normalizzata:", normalized_formula)

    parsed = do_parsingNatSL(normalized_formula)
    if parsed:
        try:
            validate_bindings(parsed)
            print("Formula Parsata:", parsed)

            skolemized = skolemize_formula(parsed)
            print("Formula Skolemizzata:", skolemized)

            agent_count = count_agents(parsed)
            print("Numero di Agenti:", agent_count)

            existential_agents = extract_existential_agents(parsed)
            print("Agenti Esistenziali:", existential_agents)

            universal_agents = extract_universal_agents(parsed)
            print("Agenti Universali:", universal_agents)

            temporal_operator_and_prop = extract_formula(parsed)
            print("Operatore Temporale e Proposizione:", temporal_operator_and_prop)

            ctl_formula = convert_natsl_to_ctl(parsed, flag)
            print("CTL Formula:", ctl_formula)

        except ValueError as e:
            print(e)
    else:
        print("Errore nel parsing della formula.")

