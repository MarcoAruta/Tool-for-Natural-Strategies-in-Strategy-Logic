from src.natSL import natSLmc
import multiprocessing

def algorithm():
    path = 'C:\\Users\\utente\\Desktop\\Lavoro\\NatSL\\Testing\\Correttezza\\Exists Eventually with n agents\\testing1\\testing.txt'
    result = 'C:\\Users\\utente\\Desktop\\Lavoro\\NatSL\\Testing\\Correttezza\\Exists Eventually with n agents\\testing1\\risultatoNatSL.txt'
    formula = 'C:\\Users\\utente\\Desktop\\Lavoro\\NatSL\\Testing\\Correttezza\\Exists Eventually with n agents\\testing1\\formulaNatSL.txt'

    # main function
    natSLmc(path, formula, result)

if __name__ == "__main__":
    process = multiprocessing.Process(target=algorithm)
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()

#PROSSIMI TEST: CON 3 AGENTI GENERAZIONE DI STRATEGIE NON FUNZIONA


