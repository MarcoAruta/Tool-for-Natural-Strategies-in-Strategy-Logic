from src.strategies import initialize, generate_guarded_action_pairs, create_reg_exp, generate_strategies
from src.pruning import pruning
from util.read_input import get_states, get_number_of_states
from src.tree import build_tree_from_CGS
import time
import copy


def generate_universal_strategies(cgs, height, k, atomic_propositions, actions_list, agents, CTLformula, filename,
                                  results_file):
    """Genera e verifica strategie universali su un insieme di alberi."""
    tree_list = [build_tree_from_CGS(cgs, get_states(), height)]
    for tree in tree_list:
        under_exam = False
        reg_exp = create_reg_exp(k, atomic_propositions)
        conditions = list(reg_exp)
        actions = list(actions_list)
        cartesian_products = generate_guarded_action_pairs(conditions, actions)
        strategies_iterator = generate_strategies(cartesian_products, k, agents, False)
        all_strategies_success = True  # Flag universale per verifica strategie per l'albero corrente

        for collective_strategy in strategies_iterator:
            tree_copy = copy.deepcopy(tree)
            if pruning(tree_copy, height, filename, CTLformula, *collective_strategy):
                under_exam = True
            else:
                all_strategies_success = False
                break  # Interrompe l'esecuzione appena una strategia fallisce

        if all_strategies_success and under_exam:
            with open(results_file, 'w') as f:
                f.write(f"Solution found with tree: {tree} and strategy: {collective_strategy}")
            return True
    return False  # Se nessuna strategia universale ha trovato una soluzione


def natSLmc(model, formula, results_file):
    start_time = time.time()
    found_solution = False
    flag = 1
    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, filename, cgs = initialize(model, formula, flag)
    i = 1
    height = 4  # Altezza massima, 5 per ottenere risultati con RT

    while not found_solution and i <= k:
        tree = build_tree_from_CGS(cgs, get_states(), height)
        reg_exp = create_reg_exp(k, atomic_propositions)
        conditions = list(reg_exp)
        actions = list(actions_list)
        cartesian_products = generate_guarded_action_pairs(conditions, actions)
        strategies_iterator = generate_strategies(cartesian_products, k, agents, found_solution)

        for collective_strategy in strategies_iterator:
            tree_copy = copy.deepcopy(tree)
            if pruning(tree_copy, height, filename, CTLformula, *collective_strategy):
                with open(results_file, 'w') as f:
                    f.write(f"Solution found: {collective_strategy}")
                found_solution = True
                break
            else:
                # Passa alla generazione di strategie universali
                found_solution_universal = generate_universal_strategies(
                    cgs, height, k, atomic_propositions, actions_list, agents, CTLformula, filename, results_file
                )
                if found_solution_universal:
                    found_solution = True
                    break  # Esci se una soluzione è stata trovata tramite strategie universali

        if not found_solution:
            print(f"No Solution found for existential strategies at iteration {i}")
            flag = 0
            k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, filename, cgs = initialize(model,
                                                                                                                formula,
                                                                                                                flag)
            i = 1
        else:
            i += 1

    if not found_solution:
        print("No Solution found")
        with open(results_file, 'w') as f:
            f.write("No solution found")

    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Elapsed time is {elapsed_time} seconds.")
    with open(results_file, 'w') as f:
        f.write(f"time is {elapsed_time}")


