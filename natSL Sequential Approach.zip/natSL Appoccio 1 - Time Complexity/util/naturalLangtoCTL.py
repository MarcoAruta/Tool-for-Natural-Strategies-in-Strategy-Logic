import re

# Mapping from natural language expressions to CTL operators
natural_to_ctl_en = {
    r'\bfor all paths\b': 'A',
    r'\bthere exists a path\b': 'E',
    r'\bglobally\b': 'G',
    r'\bnext\b': 'X',
    r'\beventually\b': 'F',
    r'\buntil\b': 'U',
    r'\breleased\b': 'R',
    r'\bnot\b': '!',
    r'\band\b': '&&',
    r'\bor\b': '||',
    r'\bimplies\b': '->',
    r'\(\s*': '(',
    r'\s*\)': ')',
    r'\bprop\b': 'p',  # Example placeholder for propositions
}

# Function to convert natural language sentence into CTL formula
def natural_language_to_ctl_en(sentence):
    # Apply the substitutions from natural language to CTL syntax
    ctl_formula = sentence.lower()
    for natural_expr, ctl_expr in natural_to_ctl_en.items():
        ctl_formula = re.sub(natural_expr, ctl_expr, ctl_formula)

    return ctl_formula

# Example usage of the function
if __name__ == "__main__":
    sentence = "for all paths globally not prop implies eventually prop"
    ctl_formula = natural_language_to_ctl_en(sentence)
    print(f"Natural language sentence: {sentence}")
    print(f"CTL formula: {ctl_formula}")
