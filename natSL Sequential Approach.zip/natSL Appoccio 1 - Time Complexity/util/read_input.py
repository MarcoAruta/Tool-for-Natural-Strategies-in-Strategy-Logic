import numpy as np

graph = []
states = []
atomic_propositions = []
matrix_prop = []
initial_state = ''
number_of_agents = ''


# The function is used to read the content of the input file representing the model.
# It is designed in such a way that it can recognize the different parts of the text based
# on their title and appropriately divide it into sections.
# The different elements are then inserted into appropriate data structures.
def read_file(filename):
    global graph, states, atomic_propositions, matrix_prop, initial_state, number_of_agents, states_counter, atomic_propositions_counter

    with open(filename, 'r') as f:
        lines = f.readlines()

    # reset: global initializations
    graph = []
    states = []
    atomic_propositions = []
    matrix_prop = []
    initial_state = ''
    number_of_agents = ''
    states_counter = 0
    atomic_propositions_counter = 0

    current_section = None
    transition_content = ''
    unknown_transition_content = ''
    name_state_content = ''
    atomic_propositions_content = ''
    labelling_content = ''
    rows_graph = []
    rows_prop = []

    for line in lines:
        line = line.strip()
        if line == 'Transition':
            current_section = 'Transition'
        elif line == 'Unkown_Transition_by':
            current_section = 'Unknown_Transition_by'
        elif line == 'Name_State':
            current_section = 'Name_State'
        elif line == 'Initial_State':
            current_section = 'Initial_State'
        elif line == 'Atomic_propositions':
            current_section = 'Atomic_propositions'
        elif line == 'Labelling':
            current_section = 'Labelling'
        elif line == 'Number_of_agents':
            current_section = 'Number_of_agents'
        elif current_section == 'Transition':
            transition_content += line + '\n'
            values = line.strip().split()
            rows_graph.append(values)
        elif current_section == 'Unknown_Transition_by':
            unknown_transition_content += line + '\n'
        elif current_section == 'Name_State':
            name_state_content += line + '\n'
            values = line.strip().split()
            states = np.array(values)
            states_counter = len(values)  # Aggiornamento di states_counter con il numero di stati
        elif current_section == 'Initial_State':
            initial_state = line
        elif current_section == 'Atomic_propositions':
            atomic_propositions_content += line + '\n'
            values = line.strip().split()
            atomic_propositions = np.array(values)
            atomic_propositions_counter = len(values)
        elif current_section == 'Labelling':
            labelling_content += line + '\n'
            values = line.strip().split()
            rows_prop.append(values)
        elif current_section == 'Number_of_agents':
            number_of_agents = line

    grafo_prov = np.array(rows_graph)
    for row in grafo_prov:
        new_row = []
        for item in row:
            if item == '0':
                new_row.append(0)
            else:
                new_row.append(str(item))
        graph.append(new_row)

    # row = state, column = atom
    matrix_prop_prov = np.array(rows_prop)
    for row in matrix_prop_prov:
        new_row = []
        for item in row:
            if item == '0':
                new_row.append(0)
            elif item == '1':
                new_row.append(1)
            else:
                new_row.append(str(item))
        matrix_prop.append(new_row)

# It represents the model.
# Transitions are indicated through the actions performed by the agents from the source state (row) to the destination state (column).
def get_graph():
    return graph

# It returns the name of the states.
def get_states():
    return states

# returns the name of the atomic propositions
def get_atomic_prop():
    return atomic_propositions

def get_number_of_atomic_prop():
    return int(atomic_propositions_counter)

# It returns a matrix that represents the atom labeling function.
# The rows represent the states, and the columns represent the atoms.
# The matrix indicates the values (between 0 and 1) of the atoms in each state.
def get_matrix_proposition():
    return matrix_prop


# returns the initial state
def get_initial_state():
    return initial_state


# returns the number of agents
def get_number_of_agents():
    return int(number_of_agents)

def check_agents_constraint(formula_agents):
    if (formula_agents != int(number_of_agents)):
        return False
    else:
        return True
def get_number_of_states():
    return int(states_counter)

def get_actions(graph, agents):
    # Convert the graph string to a list of lists
    graph_list = graph

    # Create a dictionary to store actions for each agent
    actions_per_agent = {f"agent{agent}": [] for agent in agents}

    for row in graph_list:
        for elem in row:
            if elem != 0 and elem != '*':
                actions = elem.split(',')
                for action in actions:
                    for i, agent in enumerate(agents):
                        if action[agent - 1] != 'I':  # idle condition
                            actions_per_agent[f"agent{agent}"].append(action[agent - 1])

    # Remove duplicates from each agent's action list
    for agent_key in actions_per_agent:
        actions_per_agent[agent_key] = list(set(actions_per_agent[agent_key]))

    return actions_per_agent

#Function that returns the action for agents involved in that state (instead of returning the actions available for the whole matrix as get_actions() already does)
def get_actions_for_state(graph, missing_agents, state, involved_agents_actions):
    graph_list = graph
    state_index = int(state[1:])# Extract the number from the state string and convert to integer
    actions_per_agent = {f"agent{agent}": [] for agent in missing_agents}

    row = graph_list[state_index]
    fallback_required = True

    for elem_index, elem in enumerate(row):
        if elem != 0 and elem != '*':
            actions = elem.split(',')
            # Check if the actions for the involved agents are present in the tuple
            if all(involved_agents_actions.get(f"agent{agent + 1}", 'I') == action for agent, action in enumerate(actions[:-1])):
                fallback_required = False
                # Extract the action for the missing agent
                for i, agent in enumerate(missing_agents):
                    if actions[agent - 1] != 'I': # case different from idle condition
                        # Append the action along with the state index (e.g., "Z" and "s0")
                        actions_per_agent[f"agent{agent}"].append((actions[agent - 1], f"s{elem_index}"))

    if fallback_required:
        for elem_index, elem in enumerate(row):
            if elem == 'I' * len(actions):
                for agent in missing_agents:
                    actions_per_agent[f"agent{agent}"].append(('I', f"s{elem_index}"))

    # Remove duplicates from each agent's action list and sort by state index
    for agent_key in actions_per_agent:
        actions_per_agent[agent_key] = sorted(list(set(actions_per_agent[agent_key])), key=lambda x: x[1])

    return actions_per_agent

def get_states_for_involved_agents_actions(graph, state, involved_agents_actions):
    # Estrai il numero dello stato (es. da "s0" a 0)
    state_index = int(state[1:])

    # Concatena le azioni degli agenti coinvolti
    actions = ''.join([action for actions in involved_agents_actions.values() for action in actions])

    # Ottieni la riga corrispondente allo stato dalla matrice di transizione
    row = graph[state_index]

    # Inizializza una lista per memorizzare gli indici di corrispondenza
    matching_indices = []

    # Analizza ogni elemento della riga
    for index, element in enumerate(row):
        # Salta gli elementi vuoti o pari a 0
        if element == 0 or element == '0':
            continue

        # Verifica se la stringa delle azioni è presente nell'elemento
        if actions in element.replace(',', ''):
            matching_indices.append(f"s{index}")

    # Se non sono stati trovati match e la stringa delle azioni non è vuota
    if not matching_indices and actions:
        # Cerca le occorrenze di "I" pari alla lunghezza della stringa delle azioni
        for index, element in enumerate(row):
            if element.count('I') == len(actions):
                matching_indices.append(f"s{index}")

    return matching_indices

#return the number of actions extracted in get_actions()
def get_number_of_actions ():

    n = get_actions()
    return len(n)

def write_updated_file(input_filename, modified_graph, output_filename):
    if modified_graph is None:
        raise ValueError("modified_graph is None")
    with open(input_filename, 'r') as input_file, open(output_filename, 'w') as output_file:
        current_section = None
        matrix_row = 0
        for line in input_file:
            line = line.strip()

            if line == 'Transition':
                current_section = 'Transition'
                output_file.write(line + '\n')
            elif current_section == 'Transition' and matrix_row < len(modified_graph):
                output_file.write(' '.join([str(elem) for elem in modified_graph[matrix_row]]) + '\n')
                matrix_row += 1
            elif current_section == 'Transition' and matrix_row == len(modified_graph):
                current_section = None
                output_file.write('Unkown_Transition_by' + '\n')
            else:
                output_file.write(line + '\n')

#returns the edges of a graph
def get_edges():
    graph = get_graph()
    states = get_states()
    #duplicate edges (double transactions from "a" to "b") are ignored due to model checking
    edges = []
    for i, row in enumerate(graph):
        for j, element in enumerate(row):
            if element == '*':
                edges.append((states[i], states[i]))
            elif element != 0:
                edges.append((states[i], states[j]))
    return edges

def get_edges_with_inputs(graph, states):
    # Calcola le transizioni da un grafo in input e restituisce una lista di archi (edges)
    edges = []
    for i, row in enumerate(graph):
        for j, element in enumerate(row):
            if element == '*':
                edges.append((states[i], states[i]))
            elif element != 0:
                edges.append((states[i], states[j]))
    return edges

#returns the transitions of a graph with their respective actions (as each transition is labelled with an action)
def get_edges_with_actions(graph, agents):
    states = get_states()
    # Utilizza la funzione get_actions per ottenere le azioni per agente
    actions_per_agent = get_actions(graph, agents)

    edges_with_actions = []
    for i, row in enumerate(graph):
        for j, element in enumerate(row):
            if element == '*' or element != 0:
                # Estrai le azioni associate a questa transizione
                actions = element.split(',')
                actions_list = []
                for action in actions:
                    action_details = {}
                    for agent_index, agent in enumerate(agents):
                        #if action[agent_index] != 'I':  # Condizione di inattività: non riporto "I" perchè vien da se che in ogni stato un agente può fare idle
                        action_details[f"agent{agent}"] = action[agent_index]
                    actions_list.append(action_details)

                # Aggiungi la transizione e le azioni associate all'elenco degli archi
                if element == '*':
                    edges_with_actions.append((states[i], states[i], actions_list))
                else:
                    edges_with_actions.append((states[i], states[j], actions_list))

    return edges_with_actions

def file_to_string(filename):
    with open(filename, 'r') as file:
        data = file.read()
    return data

def get_atomic_propositions_for_states(propositions, labelling_matrix, states):
    """
    This function returns the atomic propositions that are true (correspond to "1")
    for the specified states in the labelling matrix.

    Parameters:
    - propositions: List of atomic propositions (e.g., ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']).
    - labelling_matrix: 2D list where each row corresponds to a state and each column to an atomic proposition.
    - states: List of states for which to find the corresponding atomic propositions (e.g., ['s0']).

    Returns:
    - Dictionary where keys are the states and values are lists of atomic propositions that are true for those states.
    """
    # Initialize a dictionary to store the result
    result = {}

    # Map state names to their corresponding indices (assuming 's0' corresponds to index 0, 's1' to index 1, and so on)
    state_indices = {f's{i}': i for i in range(len(labelling_matrix))}

    # Iterate over the list of states
    for state in states:
        # Get the index of the current state
        state_index = state_indices[state]
        # Get the labelling row for the current state
        labelling_row = labelling_matrix[state_index]
        # Find the atomic propositions that are true for the current state
        true_props = [propositions[i] for i, val in enumerate(labelling_row) if val == 1]
        # Add the result to the dictionary
        result[state] = true_props

    return result

def get_unique_values_from_dict_values(dictionary):
    """
    This function takes a dictionary as input and returns a list of unique values from the dictionary values.

    Parameters:
    - dictionary: A dictionary where the keys are state names and the values are lists of atomic propositions.

    Returns:
    - A list of unique atomic propositions from the dictionary values.
    """
    unique_values = []
    for state, props in dictionary.items():
        for prop in props:
            if prop not in unique_values:
                unique_values.append(prop)
    return unique_values


def get_reachable_states(transitions, initial_state):
    from collections import deque

    # Crea un dizionario che mappa ogni stato agli stati che può raggiungere
    transition_dict = {}
    for src, dest in transitions:
        if src not in transition_dict:
            transition_dict[src] = []
        transition_dict[src].append(dest)

    # Inizializza la coda per BFS e il set di stati visitati
    queue = deque([initial_state])
    reachable_states = set()

    # BFS per trovare tutti gli stati raggiungibili
    while queue:
        state = queue.popleft()
        if state not in reachable_states:
            reachable_states.add(state)
            if state in transition_dict:
                for next_state in transition_dict[state]:
                    if next_state not in reachable_states:
                        queue.append(next_state)

    return reachable_states


def update_cgs_file(input_file, modified_file, tree, tree_states, unwinded_CGS):
    def read_input_file(file_path):
        with open(file_path, 'r') as file:
            lines = file.readlines()
        return lines

    def write_output_file(file_path, lines):
        with open(file_path, 'w') as file:
            file.writelines(lines)

    def update_transitions(lines, new_transitions):
        transition_start = lines.index("Transition\n") + 1
        transition_end = lines.index("Unkown_Transition_by\n")
        updated_lines = lines[:transition_start] + new_transitions + lines[transition_end:]
        return updated_lines

    def update_name_state(lines, states):
        name_state_start = lines.index("Name_State\n") + 1
        initial_state_index = lines.index("Initial_State\n")
        states_line = " ".join(states) + "\n"
        updated_lines = lines[:name_state_start] + [states_line] + lines[initial_state_index:]
        return updated_lines

    def update_labelling(lines, labelling):
        labelling_start = lines.index("Labelling\n") + 1
        num_agents_index = lines.index("Number_of_agents\n")
        updated_lines = lines[:labelling_start] + labelling + lines[num_agents_index:]
        return updated_lines

    # Lettura del file di input
    lines = read_input_file(input_file)

    # Formattazione delle transizioni come richiesto
    new_transitions = []
    for row in unwinded_CGS:
        new_transitions.append(" ".join(map(str, row)) + "\n")

    # Aggiornamento delle transizioni nel file
    lines = update_transitions(lines, new_transitions)

    # Aggiornamento della lista degli stati nel file
    lines = update_name_state(lines, tree_states)

    # Creazione delle label rows dall'albero
    labelling = []

    def traverse_and_collect_labels(node):
        labelling.append(" ".join(map(str, node.label_row)) + "\n")
        for child in node.children:
            traverse_and_collect_labels(child)

    traverse_and_collect_labels(tree)

    # Aggiornamento delle label rows nel file
    lines = update_labelling(lines, labelling)

    # Scrittura del file di output aggiornato
    write_output_file(modified_file, lines)